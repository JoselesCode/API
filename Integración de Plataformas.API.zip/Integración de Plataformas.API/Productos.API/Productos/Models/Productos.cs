﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Productos.Models
{
    public class Productos
    {
        public string Id { get; set; }
        public string NombreProducto { get; set; }
        public int Precio { get; set; }

    }
}
