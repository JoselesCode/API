﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Productos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosControllers
    {
        private static IList<ProductosControllers> lista = new List<ProductosControllers>();

        // GET: api/<ClienteController>
        [HttpGet]
        public IEnumerable<ProductosControllers> Get()
        {
            return lista;
        }

        // GET api/<ClienteController>/5
        [HttpGet("{id}")]
        public ProductosControllers Get(int id)
        {
            return lista.FirstOrDefault(x => x.id == id);
        }

        // POST api/<ClienteController>
        [HttpPost]
        public void Post([FromBody] ProductosControllers value)
        {
            lista.Add(value);
        }

        // PUT api/<ClienteController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] ProductosControllers value)
        {
            ProductosControllers selection = lista.FirstOrDefault(x => x.id == id);
            lista[lista.IndexOf(selection)] = value;
        }

        // DELETE api/<ClienteController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            lista.Remove(lista.FirstOrDefault(x => x.id == id));
        }

    }
}
